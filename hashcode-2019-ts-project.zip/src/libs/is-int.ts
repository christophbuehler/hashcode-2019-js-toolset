export function isInt(num: number): boolean {
  return ~~num === num;
}
