import chalk from 'chalk';
import { Config, Image } from '../libs/config';
import { Album } from '../shared/album';
import { Slide } from '../shared/slide';

export function main(config: Config) {
  // ToD>o
}
