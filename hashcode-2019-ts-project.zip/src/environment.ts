export enum User {
  DANIEL,
  CHRISTOPH,
  LUCA,
  SHARED,
}

export const user: User = User.CHRISTOPH;
