import chalk from 'chalk';
import { Config } from '../libs/config';

export function main() {}
