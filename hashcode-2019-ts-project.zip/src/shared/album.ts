import { Slide } from './slide';

export interface Album {
  slides: Slide[];
}
