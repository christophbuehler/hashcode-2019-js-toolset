// export const string[] = new string[] {
//   '',
//   ''
// }