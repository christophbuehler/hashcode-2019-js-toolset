export function main(): void {
  // var imgs =
}
